package be.ucll.oefening1;

public class Motor {
    public String naam;
    public int aantalPk;

    public void printInformatie() {
        System.out.println("Naam: " + naam + " \n Aantal pk:" + aantalPk);
    }
}
