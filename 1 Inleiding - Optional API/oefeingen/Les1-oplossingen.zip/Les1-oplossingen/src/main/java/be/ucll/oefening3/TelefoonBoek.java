package be.ucll.oefening3;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

public class TelefoonBoek {

	private final Map<String, String> telefoonNummers = new HashMap<>();

	public TelefoonBoek() {
	}

	public void voegToe(String naam, String telefoonNummer) {
		if (naam == null || telefoonNummer == null) {
			throw new IllegalArgumentException(String.format("Naam (%s) en telefoonNummer (%s) mogen niet null zijn.", naam, telefoonNummer));
		}
		telefoonNummers.put(naam, telefoonNummer);
	}

	public Optional<String> zoekTelefoonNummer(String naam) {
		return Optional.ofNullable(telefoonNummers.get(naam));
	}

	public Optional<String> zoekNaam(String telefoonNummer) {
		return telefoonNummers.entrySet().stream()
				.filter(entry -> entry.getValue().equals(telefoonNummer))
				.findFirst()
				.map(Entry::getKey);
	}
}
