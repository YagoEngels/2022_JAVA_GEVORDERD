package be.ucll.oefening6;

import be.ucll.oefening3.TelefoonBoek;

import java.util.Optional;

public class FunkyTelefoonBoek {

	private final TelefoonBoek telefoonboek = new TelefoonBoek();

	public FunkyTelefoonBoek() {
	}

	public void voegToe(String naam, String telefoonNummer) {
		telefoonboek.voegToe(naam, telefoonNummer);
	}

	public Optional<String> zoekTelefoonNummer(String naam) {
		Optional<String> s = telefoonboek.zoekTelefoonNummer(naam).filter(this::eindigtMetEvenGetal);
		s.map(gevonden -> "Eureka!").ifPresent(System.out::println);
		return s;
	}

	public Optional<String> zoekNaam(String telefoonNummer) {
		return telefoonboek.zoekNaam(telefoonNummer);
	}

	private boolean eindigtMetEvenGetal(String telefoonNummer) {
		try {
			int laatsteGetal = Integer.parseInt(telefoonNummer.substring(telefoonNummer.length() - 1));
			return laatsteGetal % 2 == 0;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}

}
