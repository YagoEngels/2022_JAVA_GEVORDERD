package be.ucll.oefening4;

import be.ucll.oefening3.TelefoonBoek;

public class StriktTelefoonBoek {

	private final TelefoonBoek telefoonboek = new TelefoonBoek();

	public StriktTelefoonBoek() {
	}

	public void voegToe(String naam, String telefoonNummer) {
		telefoonboek.voegToe(naam, telefoonNummer);
	}

	public String zoekTelefoonNummer(String naam) {
		return telefoonboek.zoekTelefoonNummer(naam).orElseThrow();
	}

	public String zoekNaam(String telefoonNummer) throws CallerNotKnownException {
		return telefoonboek.zoekNaam(telefoonNummer).orElseThrow(() -> new CallerNotKnownException(String.format(
				"Kan geen naam vinden op basis van het gegeven telefoonnummer: %s", telefoonNummer
		)));
	}

	static class CallerNotKnownException extends Exception {
		public CallerNotKnownException(String message) {
			super(message);
		}
	}
}
