package be.ucll.oefening5;

import be.ucll.oefening3.TelefoonBoek;

public class CompanyDirectory {

	private final Persoon ceo;
	private final String telefoonNummerMaatschappelijkeZetel;

	private final TelefoonBoek telefoonboek = new TelefoonBoek();

	public CompanyDirectory(Persoon ceo, String telefoonNummerMaatschappelijkeZetel) {
		this.ceo = ceo;
		this.telefoonNummerMaatschappelijkeZetel = telefoonNummerMaatschappelijkeZetel;
	}

	public void voegToe(String naam, String telefoonNummer) {
		telefoonboek.voegToe(naam, telefoonNummer);
	}

	public String zoekTelefoonNummer(String naam) {
		return telefoonboek.zoekTelefoonNummer(naam).orElse(telefoonNummerMaatschappelijkeZetel);
	}

	public Persoon zoekNaam(String telefoonNummer) {
		return telefoonboek.zoekNaam(telefoonNummer)
				.map(naam -> new Persoon(naam.substring(0, naam.indexOf(" ")), naam.substring(naam.indexOf(" ") + 1)))
				.orElse(ceo);
	}

	static class Persoon {
		private final String voornaam;
		private final String naam;

		public Persoon(String voornaam, String naam) {
			this.voornaam = voornaam;
			this.naam = naam;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;

			Persoon persoon = (Persoon) o;

			if (!voornaam.equals(persoon.voornaam)) return false;
			return naam.equals(persoon.naam);
		}

		@Override
		public int hashCode() {
			int result = voornaam.hashCode();
			result = 31 * result + naam.hashCode();
			return result;
		}

		@Override
		public String toString() {
			return "Persoon{" +
					"voornaam='" + voornaam + '\'' +
					", naam='" + naam + '\'' +
					'}';
		}
	}

}
