package be.ucll.oefening5;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CompanyDirectoryTest {

	public static final CompanyDirectory.Persoon CEO = new CompanyDirectory.Persoon("Mr.", "Important");
	public static final String TELEFOON_NUMMER_MAATSCHAPPELIJKE_ZETEL = "9876543210";

	CompanyDirectory telefoonboek;

	@BeforeEach
	void setUp() {
		telefoonboek = new CompanyDirectory(CEO, TELEFOON_NUMMER_MAATSCHAPPELIJKE_ZETEL);
	}


	@Test
	void zoekTelefoonNummer() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");

		String josNummer = telefoonboek.zoekTelefoonNummer("Jos Vermeulen");

		assertEquals(josNummer, "0123456789");
	}

	@Test
	void zoekTelefoonNummerNietGevonden() {
		String jefNummer = telefoonboek.zoekTelefoonNummer("Jef Verstappen");

		assertEquals(jefNummer, TELEFOON_NUMMER_MAATSCHAPPELIJKE_ZETEL);
	}

	@Test
	void zoekNaam() throws Exception {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");

		CompanyDirectory.Persoon jos = telefoonboek.zoekNaam("0123456789");

		Assertions.assertEquals(jos, new CompanyDirectory.Persoon("Jos", "Vermeulen"));
	}

	@Test
	void zoekNaamNietGevonden() {
		CompanyDirectory.Persoon ceo = telefoonboek.zoekNaam("0111111111");

		assertEquals(ceo, CEO);
	}
}