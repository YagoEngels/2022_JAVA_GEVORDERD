package be.ucll.oefening6;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FunkyTelefoonBoekTest {

	FunkyTelefoonBoek telefoonboek;

	@BeforeEach
	void setUp() {
		telefoonboek = new FunkyTelefoonBoek();
	}


	@Test
	void zoekTelefoonNummerOneven() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");
		telefoonboek.voegToe("Jef Verstappen", "0222222222");

		Optional<String> josNummerOneven = telefoonboek.zoekTelefoonNummer("Jos Vermeulen");

		assertTrue(josNummerOneven.isEmpty());
	}

	@Test
	void zoekTelefoonNummerEven() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");
		telefoonboek.voegToe("Jef Verstappen", "0222222222");

		Optional<String> jefNummerEven = telefoonboek.zoekTelefoonNummer("Jef Verstappen");

		assertTrue(jefNummerEven.isPresent());
		assertEquals(jefNummerEven.get(), "0222222222");
	}

	@Test
	void zoekTelefoonNummerNietGevonden() {
		Optional<String> josNummer = telefoonboek.zoekTelefoonNummer("Jos Vermeulen");

		assertTrue(josNummer.isEmpty());
	}

}