package be.ucll.oefening4;

import be.ucll.oefening4.StriktTelefoonBoek.CallerNotKnownException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class StriktTelefoonBoekTest {

	StriktTelefoonBoek telefoonboek;

	@BeforeEach
	void setUp() {
		telefoonboek = new StriktTelefoonBoek();
	}


	@Test
	void zoekTelefoonNummer() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");

		String josNummer = telefoonboek.zoekTelefoonNummer("Jos Vermeulen");

		assertEquals(josNummer, "0123456789");
	}

	@Test
	void zoekTelefoonNummerNietGevonden() {
		assertThrows(NoSuchElementException.class, () -> telefoonboek.zoekTelefoonNummer("Jos Vermeulen"));

	}

	@Test
	void zoekNaam() throws Exception {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");

		String jos = telefoonboek.zoekNaam("0123456789");

		assertEquals(jos, "Jos Vermeulen");
	}

	@Test
	void zoekNaamNietGevonden() {
		assertThrows(CallerNotKnownException.class, () -> telefoonboek.zoekNaam("0123456789"));
	}
}