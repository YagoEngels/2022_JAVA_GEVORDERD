package be.ucll.oefening3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class TelefoonBoekTest {

	TelefoonBoek telefoonboek;

	@BeforeEach
	void setUp() {
		telefoonboek = new TelefoonBoek();
	}

	@Test
	void kanGeenNullTelefoonNummerToevoegen() {
		assertThrows(IllegalArgumentException.class, () -> telefoonboek.voegToe("Jos Vermeulen", null));
	}

	@Test
	void kanGeenNullNaamToevoegen() {
		assertThrows(IllegalArgumentException.class, () -> telefoonboek.voegToe(null, "0123456789"));

	}

	@Test
	void voegToeGeeftGeenExceptionMetGeldigeWaarden() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");
	}

	@Test
	void zoekTelefoonNummer() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");

		Optional<String> josNummer = telefoonboek.zoekTelefoonNummer("Jos Vermeulen");

		assertTrue(josNummer.isPresent());
		assertEquals(josNummer.get(), "0123456789");
	}

	@Test
	void zoekTelefoonNummerNietGevonden() {
		Optional<String> josNummer = telefoonboek.zoekTelefoonNummer("Jos Vermeulen");

		assertTrue(josNummer.isEmpty());
	}

	@Test
	void zoekNaam() {
		telefoonboek.voegToe("Jos Vermeulen", "0123456789");

		Optional<String> jos = telefoonboek.zoekNaam("0123456789");

		assertTrue(jos.isPresent());
		assertEquals(jos.get(), "Jos Vermeulen");
	}

	@Test
	void zoekNaamNietGevonden() {
		Optional<String> jos = telefoonboek.zoekNaam("0123456789");

		assertTrue(jos.isEmpty());
	}
}