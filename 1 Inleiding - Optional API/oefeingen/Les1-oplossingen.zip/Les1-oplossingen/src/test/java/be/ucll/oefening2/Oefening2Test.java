package be.ucll.oefening2;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 * Is er hier risico voor een NPE?
 */
public class Oefening2Test {

	@Test
	@DisplayName("Er is geen NPE als je null meegeeft als parameter aan equals.")
	void instanceMethod() {
		boolean result = "Hello".equals(null);
		//Het resultaat is false.
		assertFalse(result);
	}
}
