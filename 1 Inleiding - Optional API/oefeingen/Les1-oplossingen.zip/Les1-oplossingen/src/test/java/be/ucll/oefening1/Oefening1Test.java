package be.ucll.oefening1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test die over alle gevallen van NPE gaat die gedocumenteerd staan in:
 * https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/NullPointerException.html
 */
public class Oefening1Test {

	@Test
	void fieldModify() {
		Motor motor = null;
		assertThrows(NullPointerException.class, () -> {
			motor.naam = "Jan";
		});
	}

	@Test
	void fieldAccess() {
		Motor motor = null;
		assertThrows(NullPointerException.class, () -> {
			System.out.println(motor.naam);
		});
	}

	@Test
	void functionCall() {
		Motor motor = null;
		assertThrows(NullPointerException.class, () -> {
			motor.printInformatie();;
		});
	}

}
